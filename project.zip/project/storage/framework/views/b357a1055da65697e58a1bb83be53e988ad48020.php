<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-md-8">
				<div class="row mb-5"> 
					<?php if(count($posts)>0): ?>
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4">
							<div class="card">
							  <a href="<?php echo e(url('detail/'.Str::slug($post->title).'/'.$post->id)); ?>"><img src="<?php echo e(asset('imgs/thumb/'.$post->thumb)); ?>" class="card-img-top" alt="<?php echo e($post->title); ?>" /></a>
							  <div class="card-body">
							    <h5 class="card-title"><a href="<?php echo e(url('detail/'.Str::slug($post->title).'/'.$post->id)); ?>"><?php echo e($post->title); ?></a></h5>
							  </div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<p class="alert alert-danger">No Post Found</p>
					<?php endif; ?>
				</div>
				<!-- Pagination -->
				<?php echo e($posts->links()); ?>

			</div>
			<!-- Right SIdebar -->
			<div class="col-md-4">
				<!-- Search -->
				<div class="card mb-4">
					<h5 class="card-header">Search</h5>
					<div class="card-body">
						<form action="<?php echo e(url('/')); ?>">
							<div class="input-group">
							  <input type="text" name="q" class="form-control" />
							  <div class="input-group-append">
							    <button class="btn btn-dark" type="button" id="button-addon2">Search</button>
							  </div>
							</div>
						</form>
					</div>
				</div>
				
			</div>
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelProject\project\resources\views/home.blade.php ENDPATH**/ ?>