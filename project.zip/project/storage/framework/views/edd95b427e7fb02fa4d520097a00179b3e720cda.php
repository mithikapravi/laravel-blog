<?php $__env->startSection('title',$detail->title); ?>
<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-md-8">
				<?php if(Session::has('success')): ?>
					<p class="text-success"><?php echo e(session('success')); ?></p>
				<?php endif; ?>
				<div class="card">
					<h5 class="card-header">
						<?php echo e($detail->title); ?>

						<span class="float-right">Total Views=<?php echo e($detail->views); ?></span>
					</h5>
					<img src="<?php echo e(asset('imgs/full/'.$detail->full_img)); ?>" class="card-img-top" alt="<?php echo e($detail->title); ?>">
					<div class="card-body">
						<?php echo e($detail->detail); ?>

					</div>
					<div class="card-footer">
						In <a href="<?php echo e(url('category/'.Str::slug($detail->category->title).'/'.$detail->category->id)); ?>"><?php echo e($detail->category->title); ?></a>
					</div>
				</div>
				<?php if(auth()->guard()->check()): ?>
				<!-- Add Comment -->
				<div class="card my-5">
					<h5 class="card-header">Add Comment</h5>
					<div class="card-body">
						<form method="post" action="<?php echo e(url('save-comment/'.Str::slug($detail->title).'/'.$detail->id)); ?>">
						<?php echo csrf_field(); ?>
						<textarea name="comment" class="form-control"></textarea>
						<input type="submit" class="btn btn-dark mt-2" />
					</div>
				</div>
				<?php endif; ?>
				<!-- Fetch Comments -->
				<div class="card my-4">
					<h5 class="card-header">Comments <span class="badge badge-dark"><?php echo e(count($detail->comments)); ?></span></h5>
					<div class="card-body">
						<?php if($detail->comments): ?>
							<?php $__currentLoopData = $detail->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<blockquote class="blockquote">
								  <p class="mb-0"><?php echo e($comment->comment); ?></p>
								  <?php if($comment->user_id==0): ?>
								  <footer class="blockquote-footer">Admin</footer>
								  <?php else: ?>
								  <footer class="blockquote-footer"><?php echo e($comment->user->name); ?></footer>
								  <?php endif; ?>
								</blockquote>
								<hr/>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<!-- Right SIdebar -->
			<div class="col-md-4">
				<!-- Search -->
				<div class="card mb-4">
					<h5 class="card-header">Search</h5>
					<div class="card-body">
						<form action="<?php echo e(url('/')); ?>">
							<div class="input-group">
							  <input type="text" name="q" class="form-control" />
							  <div class="input-group-append">
							    <button class="btn btn-dark" type="button" id="button-addon2">Search</button>
							  </div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelProject\project\resources\views/detail.blade.php ENDPATH**/ ?>